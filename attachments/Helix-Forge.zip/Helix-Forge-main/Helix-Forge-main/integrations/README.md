# Integrations

External system configurations. Each YAML file describes one adapter.

## Available adapters
| Adapter | Purpose | Status |
|---|---|---|
| `labarchives.yaml` | LabArchives ELN — inventory & entry sync | ✅ HMAC verified |
| `tooluniverse.yaml` | 600+ tools via OpenTargets, DisGeNET, ClinVar, OrphaNet, GWAS | ✅ Configured |
| `omim.yaml` | OMIM disease-gene mappings | ✅ Configured |
| `uniprot.yaml` | UniProt protein reference data | ✅ Public, no auth |

## Enabling an integration
Set `enabled: true` and configure credentials via environment variables.
Sandbox mode (`sandbox: true`) returns synthetic fixtures without network calls.
