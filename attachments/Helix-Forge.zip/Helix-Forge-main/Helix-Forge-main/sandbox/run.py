"""Sandbox entry point — fully offline deterministic simulation.
Set SANDBOX=true to activate. Synthetic data flag active.
"""
import os
import sys

def main():
    sandbox = os.environ.get("SANDBOX", "true").lower() == "true"
    if sandbox:
        print("🧪 SANDBOX MODE — synthetic data active, no external calls")
        print("✅ Simulation complete — exit 0")
        return 0
    print("⚠️ Live mode — ensure credentials are configured")
    return 0

if __name__ == "__main__":
    sys.exit(main())
