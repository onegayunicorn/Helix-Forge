"""Webhook event handlers for Helix-Forge.

Receives events from external systems and dispatches to internal pipelines.
All webhooks verify HMAC signatures before processing.
"""
import hashlib
import hmac
import json
import logging
from typing import Callable, Dict

logger = logging.getLogger(__name__)

# Registry of event handlers
_HANDLERS: Dict[str, Callable] = {}


def verify_signature(payload: bytes, signature: str, secret: str) -> bool:
    """Verify HMAC-SHA-256 webhook signature."""
    expected = hmac.new(
        secret.encode(),
        payload,
        hashlib.sha256
    ).hexdigest()
    return hmac.compare_digest(expected, signature)


def register_handler(event_type: str):
    """Decorator to register a webhook handler."""
    def decorator(func: Callable) -> Callable:
        _HANDLERS[event_type] = func
        return func
    return decorator


def dispatch(event_type: str, payload: dict) -> dict:
    """Dispatch an event to its registered handler."""
    if event_type not in _HANDLERS:
        logger.warning(f"No handler for event type: {event_type}")
        return {"status": "ignored", "reason": "no_handler"}
    
    handler = _HANDLERS[event_type]
    try:
        result = handler(payload)
        return {"status": "ok", "result": result}
    except Exception as e:
        logger.error(f"Handler failed for {event_type}: {e}")
        return {"status": "error", "error": str(e)}


@register_handler("labarchives.entry.created")
def handle_eln_entry_created(payload: dict) -> dict:
    """Handle new LabArchives ELN entry — trigger concordance sync."""
    entry_id = payload.get("entry_id")
    logger.info(f"ELN entry created: {entry_id}")
    # TODO: Queue concordance sync job
    return {"entry_id": entry_id, "action": "concordance_sync_queued"}


@register_handler("labarchives.inventory.updated")
def handle_inventory_updated(payload: dict) -> dict:
    """Handle LabArchives inventory update."""
    item_id = payload.get("item_id")
    logger.info(f"Inventory updated: {item_id}")
    return {"item_id": item_id, "action": "inventory_refreshed"}


@register_handler("variant.new_evidence")
def handle_new_evidence(payload: dict) -> dict:
    """Handle new evidence for a variant — re-run concordance."""
    variant_symbol = payload.get("variant_symbol")
    source = payload.get("source")
    logger.info(f"New evidence for {variant_symbol} from {source}")
    # TODO: Trigger concordance re-synthesis
    return {"variant": variant_symbol, "action": "reconcordance_queued"}


@register_handler("system.alert")
def handle_system_alert(payload: dict) -> dict:
    """Handle system-level alerts — security, performance, etc."""
    severity = payload.get("severity", "info")
    message = payload.get("message", "")
    logger.warning(f"System alert [{severity}]: {message}")
    return {"acknowledged": True, "severity": severity}
