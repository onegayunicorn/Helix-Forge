"""Webhook HTTP receivers — FastAPI endpoints.

Mount these into the main API app or run standalone.
"""
from fastapi import APIRouter, Request, HTTPException, Header
from typing import Optional
import json
import os
import logging

from .handlers import verify_signature, dispatch

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/webhooks", tags=["webhooks"])

WEBHOOK_SECRET = os.environ.get("HELIXFORGE_WEBHOOK_SECRET", "")


@router.post("/labarchives")
async def labarchives_webhook(
    request: Request,
    x_la_signature: Optional[str] = Header(None),
):
    """LabArchives ELN event webhook receiver."""
    payload = await request.body()
    
    # Verify signature if secret is configured
    if WEBHOOK_SECRET and x_la_signature:
        if not verify_signature(payload, x_la_signature, WEBHOOK_SECRET):
            raise HTTPException(status_code=401, detail="Invalid signature")
    
    try:
        data = json.loads(payload)
    except json.JSONDecodeError:
        raise HTTPException(status_code=400, detail="Invalid JSON")
    
    event_type = data.get("event_type", "labarchives.entry.created")
    result = dispatch(event_type, data)
    return result


@router.post("/generic")
async def generic_webhook(
    request: Request,
    x_hf_signature: Optional[str] = Header(None),
):
    """Generic event webhook receiver for custom integrations."""
    payload = await request.body()
    
    if WEBHOOK_SECRET and x_hf_signature:
        if not verify_signature(payload, x_hf_signature, WEBHOOK_SECRET):
            raise HTTPException(status_code=401, detail="Invalid signature")
    
    try:
        data = json.loads(payload)
    except json.JSONDecodeError:
        raise HTTPException(status_code=400, detail="Invalid JSON")
    
    event_type = data.get("event_type", "system.alert")
    result = dispatch(event_type, data)
    return result


@router.post("/ping")
async def ping_webhook(request: Request):
    """Health-check webhook endpoint."""
    return {"status": "ok", "service": "helix-forge-webhooks"}
