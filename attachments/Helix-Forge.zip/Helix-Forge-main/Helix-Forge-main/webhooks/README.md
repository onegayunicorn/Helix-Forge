# Webhooks

Inbound event receivers and outbound notifiers.

## Inbound (receivers)
| Endpoint | Purpose |
|---|---|
| `POST /webhooks/labarchives` | LabArchives ELN events |
| `POST /webhooks/generic` | Custom/generic events |
| `POST /webhooks/ping` | Health check |

## Outbound (senders)
| Event | Trigger |
|---|---|
| `concordance.updated` | Concordance grade changes |
| `variant.analyzed` | Variant analysis completes |

## Security
All webhooks use **HMAC-SHA-256** signatures. Set `HELIXFORGE_WEBHOOK_SECRET` env var.
