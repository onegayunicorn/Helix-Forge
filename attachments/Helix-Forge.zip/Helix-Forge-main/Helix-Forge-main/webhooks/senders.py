"""Outbound webhook senders — notify external systems of Helix-Forge events."""
import hashlib
import hmac
import json
import logging
from typing import Optional
import httpx

logger = logging.getLogger(__name__)


def _sign_payload(payload: bytes, secret: str) -> str:
    """Generate HMAC-SHA-256 signature for outbound webhook."""
    return hmac.new(
        secret.encode(),
        payload,
        hashlib.sha256
    ).hexdigest()


async def send_webhook(
    url: str,
    event_type: str,
    data: dict,
    secret: str,
    timeout: float = 10.0,
) -> bool:
    """Send a signed webhook to an external URL."""
    payload = {
        "event_type": event_type,
        "data": data,
        "source": "helix-forge",
    }
    body = json.dumps(payload, separators=(",", ":")).encode()
    signature = _sign_payload(body, secret)
    
    headers = {
        "Content-Type": "application/json",
        "X-HF-Signature": signature,
        "X-HF-Event": event_type,
    }
    
    try:
        async with httpx.AsyncClient(timeout=timeout) as client:
            resp = await client.post(url, content=body, headers=headers)
            resp.raise_for_status()
            logger.info(f"Webhook delivered: {event_type} → {url} [{resp.status_code}]")
            return True
    except Exception as e:
        logger.error(f"Webhook failed: {event_type} → {url}: {e}")
        return False


async def notify_concordance_updated(url: str, variant_symbol: str, grade: str, secret: str) -> bool:
    """Notify external system that concordance grade was updated."""
    return await send_webhook(
        url=url,
        event_type="concordance.updated",
        data={"variant_symbol": variant_symbol, "grade": grade},
        secret=secret,
    )


async def notify_variant_analyzed(url: str, variant_symbol: str, summary: dict, secret: str) -> bool:
    """Notify external system that variant analysis completed."""
    return await send_webhook(
        url=url,
        event_type="variant.analyzed",
        data={"variant_symbol": variant_symbol, "summary": summary},
        secret=secret,
    )
