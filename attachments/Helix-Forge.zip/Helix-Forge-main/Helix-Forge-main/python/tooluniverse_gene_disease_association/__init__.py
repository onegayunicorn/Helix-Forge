"""ToolUniverse Gene-Disease Association bridge.
Maps 600+ scientific tools → unified interface.
Integrates: OpenTargets, DisGeNET, ClinVar, OrphaNet, GWAS Catalog.
"""
