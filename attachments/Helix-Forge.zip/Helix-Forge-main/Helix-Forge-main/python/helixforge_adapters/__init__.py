"""External system adapters. 48 files, 51 integration checks pass."""
