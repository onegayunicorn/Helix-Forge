"""FastAPI entry point."""
from fastapi import FastAPI

app = FastAPI(title="Helix-Forge API", version="0.9.0")

@app.get("/health")
def health():
    return {"status": "ok", "sandbox": True}
