"""FastAPI service layer — defined, not fully written."""
