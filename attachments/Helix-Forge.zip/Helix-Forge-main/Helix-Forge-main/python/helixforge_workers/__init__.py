"""Background task workers — Celery-based pipelines. 58 modules total."""
