"""Governance modules — audit, telemetry, federation. 14 modules total."""
