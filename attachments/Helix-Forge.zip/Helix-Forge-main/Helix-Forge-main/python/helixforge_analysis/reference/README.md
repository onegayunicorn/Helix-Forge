# DMD Reference Data

Pinned reference:
- 79 exons
- cDNA: 13,992 nt
- CDS: 11,058 nt
- Protein: 3,685 aa
- UniProt: P11532
