"""UniProt P11532 (Dystrophin) protein domain impact mapping."""

# Dystrophin domain architecture (simplified)
DOMAINS = [
    {"name": "Actin-binding", "start": 1, "end": 240},
    {"name": "Spectrin-like repeats", "start": 253, "end": 3040},
    {"name": "Cysteine-rich", "start": 3080, "end": 3360},
    {"name": "C-terminal", "start": 3361, "end": 3685},
]

def domain_impact(aa_start: int, aa_end: int) -> list:
    """Return domains affected by a variant spanning aa_start..aa_end."""
    affected = []
    for d in DOMAINS:
        if aa_start <= d["end"] and aa_end >= d["start"]:
            affected.append(d)
    return affected
