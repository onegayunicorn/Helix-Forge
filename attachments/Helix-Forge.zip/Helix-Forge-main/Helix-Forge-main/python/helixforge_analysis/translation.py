"""Variant CDS reconstruction + NMD (nonsense-mediated decay) competence."""
from typing import Optional

CODON_TABLE = {
    'AUG': 'M', 'UAA': '*', 'UAG': '*', 'UGA': '*',
    # ... full table in production
}

def reconstruct_cds(reference_cds: str, variant: dict) -> str:
    """Reconstruct variant CDS from reference + variant description."""
    return reference_cds  # placeholder

def nmd_competent(cds: str, exon_junctions: list) -> bool:
    """Determine if transcript triggers NMD:
    PTC > 50 nt upstream of last exon junction → NMD competent.
    """
    stop_pos = cds.find('TAA')  # simplified
    if stop_pos == -1:
        return False
    for junction in exon_junctions[:-1]:
        if stop_pos < junction - 50:
            return True
    return False
