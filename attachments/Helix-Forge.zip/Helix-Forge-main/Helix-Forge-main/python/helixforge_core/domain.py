"""Core domain models: Variant, Evidence, ConcordanceResult, Provenance."""
from dataclasses import dataclass, field
from datetime import datetime
from typing import List, Optional

@dataclass
class Variant:
    """A genomic variant with provenance."""
    symbol: str
    description: str
    source: str
    timestamp: datetime = field(default_factory=datetime.utcnow)

@dataclass
class Evidence:
    """A single evidence line supporting or refuting a claim."""
    variant: Variant
    source_db: str
    claim: str
    confidence: float
    is_curated: bool = False
    is_refutation: bool = False
    is_text_mined: bool = False

@dataclass
class ConcordanceResult:
    """Synthesised concordance across multiple evidence sources."""
    variant: Variant
    grade: str  # SUPPORTED | EMERGING | DISPUTED | CONFLICTED | INSUFFICIENT
    evidence_lines: List[Evidence] = field(default_factory=list)
    summary: Optional[str] = None
