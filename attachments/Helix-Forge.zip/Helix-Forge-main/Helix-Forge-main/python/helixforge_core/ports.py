"""Port interfaces for hexagonal architecture."""
from abc import ABC, abstractmethod
from typing import List
from .domain import Evidence, Variant, ConcordanceResult

class EvidenceSourcePort(ABC):
    @abstractmethod
    def fetch(self, variant: Variant) -> List[Evidence]: ...

class ConcordanceEnginePort(ABC):
    @abstractmethod
    def synthesise(self, evidence_lines: List[Evidence]) -> ConcordanceResult: ...

class ELNPort(ABC):
    @abstractmethod
    def sync_entry(self, entry_id: str, payload: dict) -> bool: ...
