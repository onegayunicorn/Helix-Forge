"""Injectable clock — prevents direct datetime.now() usage for testability."""
from datetime import datetime
from abc import ABC, abstractmethod

class Clock(ABC):
    @abstractmethod
    def now(self) -> datetime: ...

class SystemClock(Clock):
    def now(self) -> datetime:
        return datetime.utcnow()

class FixedClock(Clock):
    def __init__(self, fixed: datetime):
        self._fixed = fixed
    def now(self) -> datetime:
        return self._fixed
