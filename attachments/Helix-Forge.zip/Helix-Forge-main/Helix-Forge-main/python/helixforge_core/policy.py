"""Security & governance policies."""
from dataclasses import dataclass

@dataclass
class SecurityPolicy:
    sandbox_mode: bool = True
    require_provenance: bool = True
    max_text_mining_evidence: int = 10
    allow_external_calls: bool = False

DEFAULT_POLICY = SecurityPolicy()
