"""Custom error types for Helix-Forge."""

class HelixForgeError(Exception):
    """Base error."""

class ValidationError(HelixForgeError):
    """Input validation failed."""

class ConcordanceError(HelixForgeError):
    """Evidence concordance synthesis failed."""

class AdapterError(HelixForgeError):
    """External adapter communication failed."""

class SecurityError(HelixForgeError):
    """Security policy violation."""
