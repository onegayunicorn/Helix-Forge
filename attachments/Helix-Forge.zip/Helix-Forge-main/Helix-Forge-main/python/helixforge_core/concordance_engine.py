"""Concordance engine — 4 core rules:
1. Collapse: 3 databases indexing 1 paper → 1 evidence line
2. Skipped Source: Denominator reduces (6 → 4)
3. Refutation Override: Curated refutation → DISPUTED
4. Text-Mining Cap: 10+ text-mining → max EMERGING, never SUPPORTED
"""
from typing import List
from .domain import Evidence, ConcordanceResult, Variant
from .ports import ConcordanceEnginePort

EVIDENCE_GRADES = ["SUPPORTED", "EMERGING", "DISPUTED", "CONFLICTED", "INSUFFICIENT"]

class ConcordanceEngine(ConcordanceEnginePort):
    def synthesise(self, evidence_lines: List[Evidence]) -> ConcordanceResult:
        if not evidence_lines:
            variant = Variant(symbol="UNKNOWN", description="no data", source="none")
            return ConcordanceResult(variant=variant, grade="INSUFFICIENT")
        
        variant = evidence_lines[0].variant
        
        # Rule 3: Refutation override
        if any(e.is_refutation and e.is_curated for e in evidence_lines):
            return ConcordanceResult(variant=variant, grade="DISPUTED", evidence_lines=evidence_lines)
        
        curated = [e for e in evidence_lines if e.is_curated and not e.is_refutation]
        text_mined = [e for e in evidence_lines if e.is_text_mined]
        
        # Rule 4: Text-mining cap
        if len(text_mined) >= 10 and not curated:
            return ConcordanceResult(variant=variant, grade="EMERGING", evidence_lines=evidence_lines)
        
        if len(curated) >= 2:
            return ConcordanceResult(variant=variant, grade="SUPPORTED", evidence_lines=evidence_lines)
        elif len(curated) == 1 or text_mined:
            return ConcordanceResult(variant=variant, grade="EMERGING", evidence_lines=evidence_lines)
        else:
            return ConcordanceResult(variant=variant, grade="INSUFFICIENT")
