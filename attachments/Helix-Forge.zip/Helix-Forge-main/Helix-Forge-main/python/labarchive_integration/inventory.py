"""LabArchives inventory API client."""
from typing import Optional
import httpx
from .signing import sign_request

class LabArchivesInventory:
    def __init__(self, api_url: str, access_key_id: str, secret: str, sandbox: bool = True):
        self.api_url = api_url.rstrip("/")
        self.access_key_id = access_key_id
        self.secret = secret
        self.sandbox = sandbox
    
    def get_entries(self, folder_id: Optional[str] = None) -> dict:
        """Fetch inventory entries."""
        if self.sandbox:
            return {"entries": [], "sandbox": True}
        url = f"{self.api_url}/api/inventory/entries"
        headers = sign_request("GET", url, self.access_key_id, self.secret)
        with httpx.Client() as client:
            resp = client.get(url, headers=headers)
            resp.raise_for_status()
            return resp.json()
