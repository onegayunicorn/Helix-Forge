"""LabArchives ELN HMAC-SHA-512 request signing.
CRITICAL: Query strings are EXCLUDED from the signing input.
Base64 '+' percent-encoding handled.
Credentials redacted in logs.
"""
import hmac
import hashlib
import base64
from urllib.parse import urlparse

def sign_request(method: str, url: str, access_key_id: str, secret: str, body: str = "") -> dict:
    """Generate HMAC-SHA-512 signed headers for LabArchives API."""
    parsed = urlparse(url)
    # CRITICAL: path only — query string excluded from signing input
    path = parsed.path
    
    message = f"{method}\n{path}\n{access_key_id}\n{body}"
    signature = hmac.new(
        secret.encode(),
        message.encode(),
        hashlib.sha512
    ).digest()
    sig_b64 = base64.b64encode(signature).decode()
    
    return {
        "LA-ACCESS-KEY-ID": access_key_id,
        "LA-SIGNATURE": sig_b64,
        "LA-SIGNATURE-METHOD": "HmacSHA512",
    }
