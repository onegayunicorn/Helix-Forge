# Legal & Attribution

Helix-Forge — Vendor-neutral laboratory knowledge & genomics integration platform
Copyright © 2026 onegayunicorn

This software is for RESEARCH & EDUCATIONAL USE ONLY.
It does not diagnose, treat, or make clinical decisions.
Not a medical device. Not for clinical use without independent validation.

Where scientific sources are cited, they belong to their respective authors.
