# Source Materials

Reference documents and specifications used to build Helix-Forge:

- `README-source.md` — Original project README
- `DDGS-System.pdf` — Digital DMD Gene Variant Integration System specification
- `Helix-Forge-Spec.pdf` — Helix-Forge blueprint
- `Accio-Link.url` — Accio shared link reference

The former `Accio-Share.mht` workspace export is intentionally not stored in this
repository. It may contain secret-bearing or session-derived material and must not be
reintroduced into source control.
