# API Reference

## Endpoints
- `GET /api/v1/variants/{symbol}` — Query variant information
- `POST /api/v1/concordance` — Run evidence concordance synthesis
- `GET /api/v1/frame/{variant}` — Reading-frame analysis
- `POST /api/v1/labarchives/sync` — Sync with LabArchives ELN
