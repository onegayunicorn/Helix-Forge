# Helix-Forge User Guide

## Quick Start
```bash
make bootstrap
make sandbox-up
```

## Sandbox Mode
Set `SANDBOX=true` to run fully offline with synthetic fixtures.
