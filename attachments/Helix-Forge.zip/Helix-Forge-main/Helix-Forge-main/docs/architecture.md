# Helix-Forge Architecture

## Overview
Vendor-neutral laboratory knowledge & genomics integration platform.

## Layers
1. **Core Domain** — helixforge_core
2. **Analysis Engine** — helixforge_analysis (DMD scientific core)
3. **API Gateway** — FastAPI + TypeScript gateway
4. **Workers** — Celery background pipelines
5. **Governance** — Audit, telemetry, federation
6. **Adapters** — External system integrations (LabArchives, ToolUniverse)
7. **Contracts** — Shared JSON schemas
