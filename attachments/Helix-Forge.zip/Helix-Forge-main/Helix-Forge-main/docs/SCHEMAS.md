# JSON Schemas

Located in `packages/contracts/`:
- `provenance.schema.json` — Data provenance trail
- `evidence.schema.json` — Scientific evidence grading
- `adapter.schema.json` — External adapter configuration
- `concordance.schema.json` — Concordance engine output
