# Changelog — Helix-Forge

## v0.9.0 — 2026-09-23
- ✅ DMD gene reference: 79 exons, 13,992 bp cDNA, 3,685 aa verified
- ✅ Reading-frame engine — 3 independent derivations, 0 disagreements
- ✅ Concordance engine — 4 core rules, 11/11 test cases pass
- ✅ LabArchives ELN adapter — HMAC-SHA-512 signing verified
- ✅ ToolUniverse gene-disease bridge — 600+ sources integrated
- ✅ Sandbox mode — fully offline deterministic simulation
- ✅ Makefile sed bug fixed — `$$schema` escaping
