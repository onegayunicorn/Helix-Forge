# Helix-Forge

**A vendor-neutral laboratory knowledge and genomics integration platform.**

Helix-Forge ingests, normalises, grades and serves life-sciences evidence from heterogeneous
external sources through a single adapter contract. It ships with first-class adapters for
gene–disease association analysis and LabArchives ELN/Inventory, and a pluggable adapter
registry so additional sources (clinical trial registries, LIMS, ELN, instrument platforms)
can be added without touching the core.

---

## 1. What this repository actually is

This is **Layers A and B only** (see [`docs/00_blueprint/07_roadmap_and_boundaries.md`](docs/00_blueprint/07_roadmap_and_boundaries.md)):

| Layer | In scope here? | Why |
|---|---|---|
| **A. Research informatics** — ingestion, annotation, in-silico analysis, dashboards | Yes — implemented | Needs only compute and public/authorised data |
| **B. Software product** — pipelines, published analyses, tooling | Yes — implemented | Needs version control and test discipline |
| **C. Preclinical wet-lab work** | No — specified only | Requires a BSL-rated facility, ethics approval, trained staff |
| **D. Manufacturing** | No — out of scope | Requires GMP facility and CMC package |
| **E. Human studies** | No — and unlawful without a sponsor, IRB/IEC approval and IND/CTA authorisation | Requires institutional authorisation |

No component in this repository diagnoses, treats, or makes a clinical decision.
Every analytical output carries an explicit provenance record and an evidence grade,
and every prediction is labelled as a prediction.

---

## 2. Architecture in one screen

```
                         ┌──────────────────────────┐
   Browser ──────────────►  services/web (Next.js)  │
                         └────────────┬─────────────┘
                                      │  typed REST / SSE
                         ┌────────────▼─────────────┐
                         │ services/api-gateway     │  NestJS BFF
                         │  auth · rate limit · BFF │
                         └────────────┬─────────────┘
                                      │  internal HTTP
                         ┌────────────▼─────────────┐
                         │ python/helixforge_api    │  FastAPI
                         │  analysis + adapter API  │
                         └────────────┬─────────────┘
                    ┌─────────────────┼─────────────────┐
                    │                 │                 │
      ┌─────────────▼──────┐  ┌───────▼────────┐  ┌─────▼──────────────┐
      │ helixforge_core    │  │ workers        │  │ helixforge_adapters│
      │ domain + ports     │  │ celery pipeline│  │ registry           │
      │ evidence grading   │  │ fan-out/retry  │  │  ├ gene_disease    │
      └────────────────────┘  └───────┬────────┘  │  ├ labarchives     │
                                      │           │  ├ clinical_trials │
                                      │           │  └ ...             │
                                      │           └─────┬──────────────┘
                    ┌─────────────────┴──────────┐      │
                    │  PostgreSQL (SoR)          │      │ HTTPS, allowlisted
                    │  Redis (broker/cache)      │      ▼
                    │  S3/MinIO (artifacts)      │   external scientific APIs
                    └────────────────────────────┘
```

The core never imports an adapter. Adapters implement ports declared in
`helixforge_core.ports` and are resolved by name at runtime through the registry.
This is the mechanism that makes the platform vendor-neutral — see
[ADR-0002](docs/adr/0002-adapter-registry-pattern.md).

---

## 3. Repository layout

```
helix-forge/
├── docs/                     Blueprint, ADRs, diagrams (the "professional" half)
│   ├── 00_blueprint/         Architecture, domain model, API contracts, security
│   ├── adr/                  Architecture Decision Records
│   └── diagrams/             Mermaid sources
├── packages/contracts/       Single source of truth for wire schemas (JSON Schema + zod + TS types)
├── python/
│   ├── helixforge_core/      Domain model, ports, evidence grading, provenance
│   ├── helixforge_adapters/  Adapter implementations + registry
│   ├── helixforge_api/       FastAPI service
│   └── helixforge_workers/   Celery pipelines, schedules, webhook dispatch
├── services/
│   ├── api-gateway/          NestJS BFF: auth, rate limiting, contract validation
│   └── web/                  Next.js operator console
├── infra/                    Docker, nginx, k8s manifests, terraform
├── ops/                      CI workflows, observability config
├── sandbox/                  Synthetic fixtures + offline simulation harness
└── tests/                    Cross-cutting integration + contract tests
```

---

## 4. Quickstart (local, no external credentials required)

The **sandbox profile** runs the entire platform against deterministic synthetic sources.
It never contacts a real scientific API and never contains patient data.

```bash
cp .env.example .env
make bootstrap          # install python + node deps
make sandbox-up         # docker compose, sandbox profile
make sandbox-seed       # load synthetic fixtures
open http://localhost:3000
```

Run the analysis path with no network access at all:

```bash
make test               # unit + contract + integration suites
make simulate           # offline end-to-end simulation, writes sandbox/artifacts/
```

## 5. Running against real sources

Real-source operation requires credentials you must obtain yourself. The platform
fails closed: with no credentials it refuses to make the request rather than falling
back to synthetic data.

| Adapter | Credential | Where to obtain |
|---|---|---|
| `labarchives` | `LABARCHIVES_ELN_API_URL`, `LABARCHIVES_ACCESS_KEY_ID`, `LABARCHIVES_ACCESS_PASSWORD`, optional `LABARCHIVES_USER_ID`, `LABARCHIVES_INVENTORY_LAB_ID` | LabArchives Enterprise programme; issued by the institution |
| `gene_disease` → DisGeNET | `DISGENET_API_KEY` | https://www.disgenet.org/api/#/Authorization |
| `gene_disease` → OMIM | `OMIM_API_KEY` | https://omim.org/api |
| `gene_disease` → OpenTargets / Monarch / GenCC / Orphanet | none | open endpoints |

`gene_disease` degrades honestly: when a key-gated source is unavailable it records a
**negative result with reason** rather than silently omitting it, and the concordance
score is computed over sources that were actually queried. See
[`docs/00_blueprint/04_adapter_contract.md`](docs/00_blueprint/04_adapter_contract.md) §4.

---

## 6. Documentation

| Document | Contents |
|---|---|
| [01_system_architecture.md](docs/00_blueprint/01_system_architecture.md) | Component topology, request lifecycles, failure domains |
| [02_domain_model.md](docs/00_blueprint/02_domain_model.md) | Entities, invariants, evidence/provenance model |
| [03_api_contracts.md](docs/00_blueprint/03_api_contracts.md) | Public REST surface, error taxonomy, versioning |
| [04_adapter_contract.md](docs/00_blueprint/04_adapter_contract.md) | The port every integration must satisfy |
| [05_data_governance_and_security.md](docs/00_blueprint/05_data_governance_and_security.md) | Trust boundaries, secret handling, PHI rules, audit |
| [06_deployment_topology.md](docs/00_blueprint/06_deployment_topology.md) | Environments, networking, scaling, DR |
| [07_roadmap_and_boundaries.md](docs/00_blueprint/07_roadmap_and_boundaries.md) | Phasing, and the hard limits of what software can do here |

## 7. Licence and attribution

Code in this repository is original work. Where an implementation follows a published
third-party specification, the source is cited inline and in
[`docs/00_blueprint/05_data_governance_and_security.md`](docs/00_blueprint/05_data_governance_and_security.md).

The LabArchives adapter implements the signature algorithm documented in the public
LabArchives ELN/Inventory method pages. Portions of its design follow the
**Scientific Agent Skills** project by K-Dense (arXiv:2609.00065); if that material
contributed to a publication, cite it as described in the skill's own notice.
