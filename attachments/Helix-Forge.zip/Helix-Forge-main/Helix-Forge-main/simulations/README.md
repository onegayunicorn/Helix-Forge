# Simulations

Computational simulations for variant effect prediction.

| Simulation | Purpose |
|---|---|
| `variant_frame_sim.py` | Random deletion frame-consequence simulation |
| `concordance_drift.py` | Evidence grade drift as literature accumulates |
| `nmd_prediction.py` | NMD competence prediction across variant positions |

## Run
```bash
SANDBOX=true python simulations/variant_frame_sim.py
```
