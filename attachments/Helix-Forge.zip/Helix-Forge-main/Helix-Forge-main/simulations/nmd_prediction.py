"""Simulate NMD (nonsense-mediated decay) competence for variant transcripts.

Rule: PTC > 50 nt upstream of last exon junction → NMD-competent.
"""
import sys
sys.path.insert(0, "python")

from helixforge_analysis.translation import nmd_competent

def simulate_nmd_variants():
    print("🧬 Simulating NMD competence across variant positions...")
    
    # Simplified exon junction map (positions in CDS)
    exon_junctions = [150, 300, 450, 600, 750, 900, 1050, 11058]
    
    test_positions = [100, 200, 500, 800, 1000, 10900]
    
    for pos in test_positions:
        # Build mock CDS with a premature stop at 'pos'
        mock_cds = "A" * pos + "TAA" + "A" * (11058 - pos - 3)
        competent = nmd_competent(mock_cds, exon_junctions)
        status = "✅ NMD-competent (degraded)" if competent else "⚠️  NMD-escape (translated)"
        print(f"  PTC at CDS pos {pos:5d}: {status}")

if __name__ == "__main__":
    simulate_nmd_variants()
    print("\n✅ NMD simulation complete")
