"""Simulate evidence concordance drift over time.

Models how evidence grades shift as new literature is published.
"""
import sys
import random
sys.path.insert(0, "python")

from helixforge_core.domain import Variant, Evidence
from helixforge_core.concordance_engine import ConcordanceEngine

def simulate_evidence_accumulation():
    print("📊 Simulating evidence accumulation over 12 time periods...")
    
    engine = ConcordanceEngine()
    v = Variant(symbol="DMD-EXON52-DEL", description="exon 52 deletion", source="simulation")
    
    evidence = []
    for period in range(1, 13):
        # Each period adds 0-3 new evidence lines
        new_count = random.randint(0, 3)
        for i in range(new_count):
            is_curated = random.random() < 0.3
            is_text_mined = not is_curated and random.random() < 0.6
            confidence = round(random.uniform(0.5, 0.95), 2)
            evidence.append(Evidence(
                variant=v,
                source_db=f"DB{period}_{i}",
                claim="pathogenic",
                confidence=confidence,
                is_curated=is_curated,
                is_text_mined=is_text_mined,
            ))
        
        result = engine.synthesise(evidence)
        print(f"  Period {period:2d}: {len(evidence):3d} evidence lines → grade={result.grade}")

if __name__ == "__main__":
    random.seed(42)
    simulate_evidence_accumulation()
    print("\n✅ Drift simulation complete")
