# Security & Data Governance

## Scope
- **Layer A** (research informatics): Public/authorised data only — safe
- **Layer B** (software product): Open, auditable, verifiable
- **Layers C–E**: Explicitly out of scope — no clinical decisions made here

## Data Rules
- No PHI/PII in this repository
- All external credentials come from environment variables only
- Sandbox mode uses deterministic synthetic fixtures — never touches real data
- Provenance trail: every result carries source + timestamp + evidence grade

## Vulnerabilities
Report responsibly via GitHub issues — or directly to the repo owner.
