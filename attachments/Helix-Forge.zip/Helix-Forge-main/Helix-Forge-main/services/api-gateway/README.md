# API Gateway

Zero-dependency TypeScript gateway. Routes requests to backend services.
