"""Experiment 002 — Exon 44 deletion skip verification.

Hypothesis: Deletion of exon 44 rescued by skipping exons 43 and 45 → in-frame.
"""
import sys
sys.path.insert(0, "python")

EXON_BOUNDARIES = {
    43: (8400, 8550),
    44: (8551, 8700),
    45: (8701, 8850),
}

def run():
    print("🧪 Experiment 002 — del44 skip verification")
    print("=" * 50)
    
    start_nt = EXON_BOUNDARIES[43][0]
    end_nt = EXON_BOUNDARIES[45][1]
    deleted = end_nt - start_nt + 1
    frame_ok = deleted % 3 == 0
    
    print(f"  Exons skipped: 43, 44, 45")
    print(f"  Nucleotides removed: {deleted}")
    print(f"  Mod-3 remainder: {deleted % 3}")
    print(f"  In-frame: {'✅ YES' if frame_ok else '❌ NO'}")
    
    assert frame_ok, "del44 skip should be in-frame"
    print("\n✅ Experiment 002 PASSED")

if __name__ == "__main__":
    run()
