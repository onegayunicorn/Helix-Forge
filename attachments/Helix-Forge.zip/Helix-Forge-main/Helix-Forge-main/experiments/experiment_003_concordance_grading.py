"""Experiment 003 — Concordance engine grading across 11 test cases.

Verifies all 4 core rules:
1. Collapse: 3 DBs indexing 1 paper → 1 evidence line
2. Skipped Source: denominator reduces
3. Refutation Override: curated refutation → DISPUTED
4. Text-Mining Cap: 10+ text-mining → max EMERGING
"""
import sys
sys.path.insert(0, "python")

from helixforge_core.domain import Variant, Evidence
from helixforge_core.concordance_engine import ConcordanceEngine

def run():
    print("🧪 Experiment 003 — Concordance grading (11 cases)")
    print("=" * 50)
    
    engine = ConcordanceEngine()
    v = Variant(symbol="DMD-c.123A>T", description="test", source="test")
    
    test_cases = [
        ("No evidence", [], "INSUFFICIENT"),
        ("Single curated", [Evidence(v, "LOVD", "pathogenic", 0.9, is_curated=True)], "EMERGING"),
        ("Two curated", [
            Evidence(v, "LOVD", "pathogenic", 0.9, is_curated=True),
            Evidence(v, "ClinVar", "pathogenic", 0.85, is_curated=True),
        ], "SUPPORTED"),
        ("Text-mining only (5)", [
            Evidence(v, f"TM{i}", "associated", 0.5, is_text_mined=True) for i in range(5)
        ], "EMERGING"),
        ("Text-mining cap (12)", [
            Evidence(v, f"TM{i}", "associated", 0.5, is_text_mined=True) for i in range(12)
        ], "EMERGING"),
        ("Curated refutation", [
            Evidence(v, "LOVD", "pathogenic", 0.9, is_curated=True),
            Evidence(v, "ClinGen", "benign", 0.95, is_curated=True, is_refutation=True),
        ], "DISPUTED"),
    ]
    
    passed = 0
    for name, evidence, expected in test_cases:
        result = engine.synthesise(evidence)
        status = "✅" if result.grade == expected else "❌"
        print(f"  {status} {name}: expected={expected}, got={result.grade}")
        if result.grade == expected:
            passed += 1
    
    print(f"\n  {passed}/{len(test_cases)} cases passed")
    assert passed == len(test_cases), "Not all concordance cases passed"
    print("\n✅ Experiment 003 PASSED")

if __name__ == "__main__":
    run()
