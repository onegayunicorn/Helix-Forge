#!/usr/bin/env python3
"""Run all Helix-Forge experiments."""
import subprocess
import sys
from pathlib import Path

def main():
    exp_dir = Path(__file__).parent
    experiments = sorted(exp_dir.glob("experiment_*.py"))
    
    print(f"🔬 Running {len(experiments)} experiments...\n")
    
    failed = []
    for exp in experiments:
        print(f"\n{'─'*60}")
        result = subprocess.run([sys.executable, str(exp)])
        if result.returncode != 0:
            failed.append(exp.name)
    
    print(f"\n{'═'*60}")
    if failed:
        print(f"❌ {len(failed)} experiment(s) FAILED: {', '.join(failed)}")
        return 1
    print(f"✅ All {len(experiments)} experiments PASSED")
    return 0

if __name__ == "__main__":
    sys.exit(main())
