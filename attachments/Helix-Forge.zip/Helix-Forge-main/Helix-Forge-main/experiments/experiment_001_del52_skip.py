"""Experiment 001 — Exon 52 deletion skip verification.

Hypothesis: Deletion of exon 52 can be rescued by skipping exons 51 and 53,
producing an in-frame transcript.

Expected: in-frame ✅
Reference: 79 exons, CDS 11,058 nt
"""
import sys
sys.path.insert(0, "python")

from helixforge_analysis.frame import is_in_frame, reading_frame_from_cds_position

# Exon boundary map (simplified — production uses full reference)
EXON_BOUNDARIES = {
    51: (10500, 10650),
    52: (10651, 10800),
    53: (10801, 10950),
}

def run():
    print("🧪 Experiment 001 — del52 skip verification")
    print("=" * 50)
    
    # Test: skip 51+53 after del52 → effectively removes 51-53
    # Net deletion length must be multiple of 3 for in-frame
    start_nt = EXON_BOUNDARIES[51][0]
    end_nt = EXON_BOUNDARIES[53][1]
    deleted = end_nt - start_nt + 1
    frame_ok = deleted % 3 == 0
    
    print(f"  Exons skipped: 51, 52, 53")
    print(f"  Nucleotides removed: {deleted}")
    print(f"  Mod-3 remainder: {deleted % 3}")
    print(f"  In-frame: {'✅ YES' if frame_ok else '❌ NO'}")
    
    assert frame_ok, "del52 skip should be in-frame"
    print("\n✅ Experiment 001 PASSED")

if __name__ == "__main__":
    run()
