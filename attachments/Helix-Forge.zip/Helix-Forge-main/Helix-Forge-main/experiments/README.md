# Experiments

Research experiments for DMD variant analysis.

| Experiment | Purpose |
|---|---|
| `experiment_001_del52_skip.py` | Verify del52 → skip 51,53 is in-frame |
| `experiment_002_del44_skip.py` | Verify del44 → skip 43,45 is in-frame |
| `experiment_003_concordance_grading.py` | Concordance engine — 11 grading test cases |

## Run all
```bash
python experiments/run_all.py
```
