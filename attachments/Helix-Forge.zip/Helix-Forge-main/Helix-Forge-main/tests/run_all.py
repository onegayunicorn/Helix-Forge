"""Helix-Forge full test runner.
297 tests total. Run with: python tests/run_all.py
"""
import sys
import pytest

def main():
    exit_code = pytest.main([
        "tests/unit",
        "tests/contract",
        "tests/integration",
        "tests/security",
        "tests/validation",
        "-v",
        "--tb=short",
    ])
    return exit_code

if __name__ == "__main__":
    sys.exit(main())
