from helixforge_analysis.frame import is_in_frame, reading_frame_from_cds_position
from helixforge_analysis.whole_locus import verify_locus
from helixforge_core.concordance_engine import ConcordanceEngine
from helixforge_core.domain import Evidence, Variant


def test_reading_frame_arithmetic():
    assert reading_frame_from_cds_position(1) == 0
    assert reading_frame_from_cds_position(2) == 1
    assert reading_frame_from_cds_position(3) == 2


def test_in_frame_deletion_uses_exon_boundaries():
    boundaries = {52: (100, 198), 53: (199, 297)}
    assert is_in_frame(52, 53, boundaries) is True
    assert is_in_frame(52, 99, boundaries) is False


def test_whole_locus_reference_is_clean():
    locus = verify_locus()
    assert locus["exons"] == 79
    assert locus["blocks_checked"] == 6319
    assert locus["disagreements"] == 0


def test_curated_evidence_supports_a_variant():
    variant = Variant(symbol="del52", description="DMD exon 52 deletion", source="sandbox")
    evidence = [
        Evidence(variant=variant, source_db="ClinVar", claim="pathogenic", confidence=0.98, is_curated=True),
        Evidence(variant=variant, source_db="UniProt", claim="reference match", confidence=0.94, is_curated=True),
    ]
    result = ConcordanceEngine().synthesise(evidence)
    assert result.grade == "SUPPORTED"
    assert result.variant.symbol == "del52"


def test_curated_refutation_overrides_support():
    variant = Variant(symbol="dup17", description="DMD exon 17 duplication", source="sandbox")
    evidence = [
        Evidence(variant=variant, source_db="OMIM", claim="legacy mismatch", confidence=0.62, is_curated=True, is_refutation=True),
        Evidence(variant=variant, source_db="ToolUniverse", claim="text-mined match", confidence=0.5, is_text_mined=True),
    ]
    assert ConcordanceEngine().synthesise(evidence).grade == "DISPUTED"
