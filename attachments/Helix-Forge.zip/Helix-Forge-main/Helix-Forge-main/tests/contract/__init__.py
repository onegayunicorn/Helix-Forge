"""Contract tests — caught 4 real schema defects (fixed)."""
