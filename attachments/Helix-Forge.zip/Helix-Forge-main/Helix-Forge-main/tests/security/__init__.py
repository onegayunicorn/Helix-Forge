"""Security tests — write-gate verified: token/expiry/replay all blocked."""
