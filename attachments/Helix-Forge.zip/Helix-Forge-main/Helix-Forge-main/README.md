# Helix Forge

Helix Forge is a vendor-neutral laboratory knowledge and genomics integration platform for DMD gene variant analysis. This repository contains the extracted Python domain and analysis packages together with an installable, offline-ready React PWA workbench.

## What is included

- **Python core**: reading-frame analysis, whole-locus verification, concordance grading, provenance-aware domain types, and a FastAPI health endpoint.
- **PWA workbench**: a responsive operational console for whole-locus verification, frame-rescue variants, evidence concordance, sandbox runs, audit activity, and install/offline metadata.
- **Contracts and integrations**: JSON schema contracts and the extracted integration/deployment documentation.
- **Deterministic sandbox**: synthetic mode that performs no external calls and requires no credentials.

## Run locally

### PWA

```bash
pnpm install
pnpm dev
```

The production build is generated with:

```bash
pnpm check
pnpm build
```

The PWA shell is defined in `client/public/manifest.json` and `client/public/sw.js`.

### Python platform

```bash
python3 -m pip install -r requirements.txt
SANDBOX=true python3 sandbox/run.py --simulate
python3 tests/run_all.py
```

The API health endpoint is available when the FastAPI app is started with Uvicorn:

```bash
uvicorn helixforge_api.main:app --app-dir python --reload
```

## Validation

The project validates its JSON contracts with the `contracts-validate` Make target. The smoke tests in `tests/unit/test_core_smoke.py` exercise frame arithmetic, whole-locus reference verification, and the concordance rules without making network calls.

## Safety and provenance

The workbench is intentionally presented as a deterministic sandbox console. It does not claim to perform clinical interpretation, and it does not make external data calls from the static frontend. Source evidence and reference values should be reviewed against current, authoritative datasets before any research or clinical use.
