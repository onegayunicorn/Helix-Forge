# Dependencies

## Locked Versions
`requirements.lock` — fully pinned transitive dependency tree.

## Vendored Code
`vendored.txt` — lists all third-party code copied directly into the source tree.

## Updating
```bash
pip-compile requirements.txt --output-file=dependencies/requirements.lock
```
