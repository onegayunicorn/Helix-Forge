# Deployment Guide

## Platforms
- `platforms/kubernetes.md` — Kubernetes deployment
- `platforms/air-gapped.md` — Air-gapped / offline deployment
- `platforms/hpc-slurm.md` — HPC / SLURM cluster deployment
- `platforms/single-node-edge.md` — Single-node edge deployment

## Quick Deploy
```bash
./deploy.sh
```
