# Single-Node Edge Deployment

Minimal deployment for edge devices and single-server installations.
