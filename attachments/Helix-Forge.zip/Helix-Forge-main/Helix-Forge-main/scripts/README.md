# Scripts

Utility scripts for Helix-Forge:

| Script | Purpose |
|---|---|
| `deploy.sh` | Deploy to target platform (k8s / air-gapped / hpc-slurm / edge) |
| `setup_dev.sh` | Local Python venv + dependency setup |
| `validate_schemas.sh` | Validate all JSON contract schemas |
| `run_sandbox.sh` | Run sandbox mode (fully offline) |
| `rotate_secrets.sh` | Generate new HMAC keys and API tokens |
