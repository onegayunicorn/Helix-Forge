#!/usr/bin/env bash
# Secret rotation helper — generates new keys for LabArchives etc.
set -euo pipefail

echo "🔐 Generating new secrets..."

# Generate HMAC key (32 bytes -> base64)
NEW_HMAC=$(python3 -c "import secrets,base64; print(base64.b64encode(secrets.token_bytes(32)).decode())")
echo "HMAC-SHA-512 key: $NEW_HMAC"

# Generate API token
NEW_TOKEN=$(python3 -c "import secrets; print(secrets.token_urlsafe(48))")
echo "API token: $NEW_TOKEN"

echo ""
echo "⚠️  Update your .env file with these values"
echo "⚠️  OLD KEYS WILL BE INVALIDATED"
