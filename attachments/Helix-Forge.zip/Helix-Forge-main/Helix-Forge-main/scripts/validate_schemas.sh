#!/usr/bin/env bash
# Validate all JSON schemas in packages/contracts/
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT_DIR="$(dirname "$SCRIPT_DIR")"
CONTRACTS="$ROOT_DIR/packages/contracts"

echo "📋 Validating JSON schemas..."

FAIL=0
for schema in "$CONTRACTS"/*.schema.json; do
  if python3 -c "import json,sys; json.load(open('$schema'))" 2>/dev/null; then
    echo "  ✅ $(basename "$schema")"
  else
    echo "  ❌ $(basename "$schema") — INVALID"
    FAIL=1
  fi
done

if [ "$FAIL" -eq 0 ]; then
  echo "✅ All schemas valid"
else
  echo "❌ Schema validation failed"
  exit 1
fi
