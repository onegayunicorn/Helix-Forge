#!/usr/bin/env bash
# Run sandbox mode — fully offline, synthetic data
set -euo pipefail

export SANDBOX=true
export LOG_LEVEL="${LOG_LEVEL:-INFO}"

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT_DIR="$(dirname "$SCRIPT_DIR")"

echo "🧪 Starting Helix-Forge in SANDBOX MODE"
echo "   No external calls — synthetic fixtures active"
echo ""

cd "$ROOT_DIR"
python sandbox/run.py "$@"
