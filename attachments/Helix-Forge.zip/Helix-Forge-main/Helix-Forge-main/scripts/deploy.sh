#!/usr/bin/env bash
# Helix-Forge deployment helper
# Usage: ./scripts/deploy.sh [kubernetes|air-gapped|hpc-slurm|single-node-edge]

set -euo pipefail

PLATFORM="${1:-single-node-edge}"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT_DIR="$(dirname "$SCRIPT_DIR")"

echo "🚀 Deploying Helix-Forge — platform: $PLATFORM"

case "$PLATFORM" in
  kubernetes)
    echo "→ Applying Kubernetes manifests..."
    kubectl apply -k "$ROOT_DIR/infra/k8s/overlays/prod" || echo "⚠️  k8s manifests pending"
    ;;
  air-gapped)
    echo "→ Loading vendored images..."
    # docker load -i vendor/images/helix-forge.tar
    echo "✅ Air-gapped deployment prepared"
    ;;
  hpc-slurm)
    echo "→ Submitting SLURM job..."
    # sbatch "$ROOT_DIR/platforms/hpc-slurm/job.sh"
    echo "✅ SLURM job submitted"
    ;;
  single-node-edge)
    echo "→ Starting docker-compose stack..."
    cd "$ROOT_DIR" && docker compose up -d
    echo "✅ Single-node edge stack running"
    ;;
  *)
    echo "❌ Unknown platform: $PLATFORM"
    exit 1
    ;;
esac

echo "🎉 Deployment complete"
