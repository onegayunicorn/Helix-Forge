#!/usr/bin/env bash
# Local development environment setup
set -euo pipefail

echo "⚡ Setting up Helix-Forge dev environment..."

# Python venv
if [ ! -d .venv ]; then
  python3 -m venv .venv
fi
source .venv/bin/activate

pip install --upgrade pip
pip install -r requirements.txt
pip install -e ".[dev]"

echo "✅ Python environment ready"
echo ""
echo "Activate with: source .venv/bin/activate"
