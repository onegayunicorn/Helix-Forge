# Contributing to Helix-Forge

Thank you for building this — every line serves a purpose.

## Code of Conduct
- Be precise. Be kind. Be honest.
- All outputs carry provenance. No black boxes.
- Patient data stays local. Always.

## Development Workflow
```bash
# Setup
make bootstrap
make sandbox-up

# Run tests
make test

# Run simulation (no network)
make simulate
```

## Branching
- `main` — production-ready
- `develop` — integration branch
- Feature branches: `feature/dmd-exon-skipping`

## Standards
- Python: `ruff check` + `black` formatting
- Commit messages: `<type>: <description>` e.g. `fix: sed escape in contracts-validate`
- All predictions explicitly labelled as predictions
