import { useMemo, useState } from "react";
import {
  Activity,
  ArrowUpRight,
  BookOpen,
  CheckCircle2,
  ChevronDown,
  CircleDot,
  Dna,
  FileCheck2,
  FlaskConical,
  Gauge,
  GitBranch,
  Info,
  Layers3,
  LockKeyhole,
  MoreHorizontal,
  PanelLeftClose,
  PanelLeftOpen,
  Play,
  RefreshCw,
  Search,
  ShieldCheck,
  Sparkles,
  Split,
  Table2,
  TerminalSquare,
  X,
  Zap,
} from "lucide-react";

type Workspace = "overview" | "locus" | "evidence" | "runs";

const navItems: { id: Workspace; label: string; icon: typeof Activity }[] = [
  { id: "overview", label: "System overview", icon: Gauge },
  { id: "locus", label: "Whole-locus verify", icon: Dna },
  { id: "evidence", label: "Evidence concordance", icon: Layers3 },
  { id: "runs", label: "Sandbox runs", icon: TerminalSquare },
];

const variants = [
  { name: "del52", locus: "DMD exon 52", status: "IN-FRAME", tone: "mint", detail: "Skip 51 + 53" },
  { name: "del44", locus: "DMD exon 44", status: "IN-FRAME", tone: "mint", detail: "Skip 43 + 45" },
  { name: "del45–53", locus: "DMD exons 45–53", status: "IN-FRAME", tone: "mint", detail: "Multi-exon rescue" },
  { name: "dup17", locus: "DMD exon 17", status: "OUT-OF-FRAME", tone: "coral", detail: "Needs repair" },
];

const evidenceRows = [
  { source: "ClinVar", kind: "Curated", claim: "Pathogenic · DMD deletion", confidence: 0.98, state: "supported" },
  { source: "UniProt", kind: "Curated", claim: "Reference protein P11532", confidence: 0.94, state: "supported" },
  { source: "ToolUniverse", kind: "Text-mined", claim: "Exon boundary concordance", confidence: 0.73, state: "emerging" },
  { source: "OMIM", kind: "Refutation", claim: "Legacy transcript mismatch", confidence: 0.62, state: "disputed" },
];

function StatCard({ label, value, suffix, note, icon: Icon, accent = "blue" }: { label: string; value: string; suffix?: string; note: string; icon: typeof Activity; accent?: "blue" | "mint" | "orange" | "violet" }) {
  return (
    <div className={`stat-card accent-${accent}`}>
      <div className="stat-icon"><Icon size={16} strokeWidth={2.2} /></div>
      <div className="stat-label">{label}</div>
      <div className="stat-value">{value}<span>{suffix}</span></div>
      <div className="stat-note">{note}</div>
    </div>
  );
}

function Donut() {
  return (
    <div className="donut-wrap" aria-label="Concordance grade distribution">
      <div className="donut"><div><strong>96.8</strong><span>% verified</span></div></div>
      <div className="donut-legend">
        <div><i className="dot dot-blue" /><span>Supported</span><b>72%</b></div>
        <div><i className="dot dot-mint" /><span>Emerging</span><b>18%</b></div>
        <div><i className="dot dot-coral" /><span>Disputed</span><b>6%</b></div>
        <div><i className="dot dot-gray" /><span>Insufficient</span><b>4%</b></div>
      </div>
    </div>
  );
}

export default function Home() {
  const [workspace, setWorkspace] = useState<Workspace>("overview");
  const [collapsed, setCollapsed] = useState(false);
  const [selectedVariant, setSelectedVariant] = useState("del52");
  const [query, setQuery] = useState("");
  const [notice, setNotice] = useState<string | null>(null);
  const [running, setRunning] = useState(false);

  const filteredEvidence = useMemo(
    () => evidenceRows.filter((row) => `${row.source} ${row.claim} ${row.kind}`.toLowerCase().includes(query.toLowerCase())),
    [query],
  );

  const runVerification = () => {
    setRunning(true);
    setNotice("Sandbox verification queued · deterministic mode");
    window.setTimeout(() => {
      setRunning(false);
      setNotice("Verification complete · 0 disagreements across 6,319 blocks");
    }, 1100);
  };

  return (
    <div className="app-shell">
      <aside className={`sidebar ${collapsed ? "collapsed" : ""}`}>
        <div className="brand">
          <div className="brand-mark"><Dna size={21} /></div>
          {!collapsed && <div><div className="brand-name">HELIX <span>FORGE</span></div><div className="brand-sub">GENOMICS WORKBENCH</div></div>}
        </div>
        <button className="collapse-button" onClick={() => setCollapsed(!collapsed)} aria-label="Toggle sidebar"><PanelLeftClose size={17} /></button>
        {!collapsed && <div className="workspace-label">Workspace</div>}
        <nav>
          {navItems.map(({ id, label, icon: Icon }) => (
            <button key={id} className={`nav-item ${workspace === id ? "active" : ""}`} onClick={() => setWorkspace(id)} title={collapsed ? label : undefined}>
              <Icon size={17} /><span>{!collapsed && label}</span>{!collapsed && id === "overview" && <span className="nav-pulse" />}
            </button>
          ))}
        </nav>
        {!collapsed && <>
          <div className="workspace-label lower">Resources</div>
          <button className="nav-item" onClick={() => setNotice("Documentation is available in the extracted /docs folder") }><BookOpen size={17} /><span>Documentation</span><ArrowUpRight size={14} className="external" /></button>
          <button className="nav-item" onClick={() => setNotice("Schema contracts are validated in CI") }><FileCheck2 size={17} /><span>Schema contracts</span></button>
          <div className="sidebar-bottom"><div className="sandbox-chip"><span className="status-dot" /> <span>Sandbox mode</span><LockKeyhole size={13} /></div><div className="version">HELIX-FORGE <b>0.9.0</b></div></div>
        </>}
      </aside>

      <main className="main-panel">
        <header className="topbar">
          <div className="crumb"><span>WORKBENCH</span><span className="slash">/</span><strong>{navItems.find((item) => item.id === workspace)?.label}</strong></div>
          <div className="top-actions"><div className="live-status"><span className="status-dot" /> Systems nominal</div><button className="icon-button" aria-label="Refresh" onClick={() => setNotice("Workspace refreshed just now")}><RefreshCw size={16} /></button><div className="avatar">OG</div></div>
        </header>

        <div className="content">
          <section className="hero-row">
            <div><div className="eyebrow"><Sparkles size={14} /> DMD VARIANT INTEGRATION SYSTEM</div><h1>Good morning, <em>operator.</em></h1><p className="hero-copy">A calm control surface for tracing variant evidence from whole-locus verification to a defensible concordance grade.</p></div>
            <div className="hero-actions"><button className="button-secondary" onClick={() => setNotice("Export is prepared in the local sandbox") }><Table2 size={15} /> Export view</button><button className="button-primary" onClick={runVerification} disabled={running}><Play size={15} fill="currentColor" /> {running ? "Running…" : "Run verification"}</button></div>
          </section>

          {notice && <div className="notice"><CheckCircle2 size={16} /><span>{notice}</span><button onClick={() => setNotice(null)} aria-label="Dismiss"><X size={15} /></button></div>}

          {workspace === "overview" && <>
            <section className="stats-grid"><StatCard label="Locus blocks verified" value="6,319" note="0 disagreements · PASS" icon={GitBranch} accent="blue" /><StatCard label="Reference protein" value="3,685" suffix=" aa" note="UniProt P11532 · DMD" icon={Dna} accent="mint" /><StatCard label="Concordance health" value="96.8" suffix="%" note="Across active evidence" icon={ShieldCheck} accent="violet" /><StatCard label="Sandbox latency" value="184" suffix=" ms" note="Synthetic · no external calls" icon={Zap} accent="orange" /></section>
            <section className="dashboard-grid">
              <div className="panel locus-panel"><div className="panel-header"><div><div className="panel-kicker">REFERENCE LOCUS</div><h2>DMD · whole-locus verification</h2></div><button className="more-button" aria-label="More options"><MoreHorizontal size={18} /></button></div><div className="locus-meta"><span><b>79</b> exons</span><span><b>13,992</b> bp cDNA</span><span><b>11,058</b> bp CDS</span><span className="pass-tag"><CheckCircle2 size={13} /> PASS</span></div><div className="exon-map">{Array.from({ length: 79 }, (_, i) => <span key={i} className={`exon ${i === 51 ? "selected" : ""} ${i === 43 || i === 45 ? "linked" : ""}`} title={`Exon ${i + 1}`} />)}</div><div className="map-labels"><span>EXON 01</span><span>ACTIVE REGION · 45–53</span><span>EXON 79</span></div><div className="panel-footer"><span><CircleDot size={13} /> Reference build GRCh38</span><span>Last verified 4 min ago</span></div></div>
              <div className="panel grades-panel"><div className="panel-header"><div><div className="panel-kicker">EVIDENCE SYNTHESIS</div><h2>Concordance grades</h2></div><button className="more-button" aria-label="More options"><MoreHorizontal size={18} /></button></div><Donut /><div className="grade-callout"><div className="callout-icon"><ShieldCheck size={16} /></div><div><b>Supported</b><span>Curated sources agree on active claims</span></div><ArrowUpRight size={15} /></div></div>
            </section>
            <section className="lower-grid"><div className="panel variant-panel"><div className="panel-header"><div><div className="panel-kicker">ACTIVE VARIANTS</div><h2>Frame rescue index</h2></div><button className="text-button" onClick={() => setWorkspace("locus")}>View all <ArrowUpRight size={14} /></button></div><div className="variant-list">{variants.map((variant) => <button key={variant.name} className={`variant-row ${selectedVariant === variant.name ? "selected" : ""}`} onClick={() => { setSelectedVariant(variant.name); setWorkspace("locus"); }}><span className={`variant-symbol ${variant.tone}`}>{variant.name}</span><span className="variant-locus">{variant.locus}<small>{variant.detail}</small></span><span className={`status-label ${variant.tone}`}>{variant.status}</span><ChevronDown size={15} className="row-chevron" /></button>)}</div></div><div className="panel activity-panel"><div className="panel-header"><div><div className="panel-kicker">RECENT ACTIVITY</div><h2>Audit trail</h2></div><button className="more-button" aria-label="More options"><MoreHorizontal size={18} /></button></div><div className="activity-list"><div><span className="activity-icon mint"><CheckCircle2 size={14} /></span><p><b>Whole-locus pass recorded</b><small>6,319 blocks · 4 min ago</small></p></div><div><span className="activity-icon blue"><Split size={14} /></span><p><b>del52 concordance updated</b><small>3 sources collapsed · 18 min ago</small></p></div><div><span className="activity-icon orange"><FlaskConical size={14} /></span><p><b>Sandbox simulation complete</b><small>Deterministic mode · 32 min ago</small></p></div></div></div></section>
          </>}

          {workspace === "locus" && <section className="workspace-view"><div className="panel detail-panel"><div className="panel-header"><div><div className="panel-kicker">WHOLE-LOCUS VERIFICATION</div><h2>Reading frame integrity</h2><p className="panel-intro">Three independent derivations must agree before a locus receives a PASS status.</p></div><span className="pass-tag large"><CheckCircle2 size={14} /> PASS</span></div><div className="verification-steps">{["Mod-3 arithmetic on CDS coordinates", "Junction-DAG traversal across exon boundaries", "Vendored reference implementation"].map((step, index) => <div className="verification-step" key={step}><div className="step-number">0{index + 1}</div><div><b>{step}</b><span>Verified against 6,319 blocks</span></div><CheckCircle2 size={17} className="step-check" /></div>)}</div><div className="integrity-banner"><Activity size={17} /><div><b>Zero disagreements</b><span>All three derivations resolve to the same reading frame.</span></div><strong>100%</strong></div></div><div className="panel variant-detail"><div className="panel-kicker">SELECTED VARIANT</div><div className="variant-detail-title"><span className="variant-symbol mint">{selectedVariant}</span><span>{variants.find((v) => v.name === selectedVariant)?.locus}</span></div><div className="detail-grid"><div><span>Frame state</span><b>IN-FRAME</b></div><div><span>Repair route</span><b>Exon skipping</b></div><div><span>Reference</span><b>GRCh38</b></div><div><span>Provenance</span><b>Sandbox synthetic</b></div></div><button className="button-primary" onClick={runVerification}><Play size={15} fill="currentColor" /> Re-run selected analysis</button></div></section>}

          {workspace === "evidence" && <section className="workspace-view"><div className="panel table-panel"><div className="panel-header"><div><div className="panel-kicker">EVIDENCE CONCORDANCE</div><h2>Source ledger</h2><p className="panel-intro">Collapse duplicate indexing, reduce skipped-source denominators, and surface curated refutations.</p></div><div className="search-field"><Search size={15} /><input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Filter evidence" /></div></div><div className="evidence-table"><div className="table-row table-head"><span>Source</span><span>Evidence type</span><span>Claim</span><span>Confidence</span><span>Grade</span></div>{filteredEvidence.map((row) => <div className="table-row" key={row.source}><span className="source-cell"><span className="source-icon"><BookOpen size={14} /></span><b>{row.source}</b></span><span><span className="kind-chip">{row.kind}</span></span><span>{row.claim}</span><span><div className="confidence"><i style={{ width: `${row.confidence * 100}%` }} /><b>{Math.round(row.confidence * 100)}%</b></div></span><span><span className={`grade-chip ${row.state}`}>{row.state}</span></span></div>)}</div></div></section>}

          {workspace === "runs" && <section className="workspace-view"><div className="panel runs-panel"><div className="panel-header"><div><div className="panel-kicker">OFFLINE EXECUTION</div><h2>Sandbox runs</h2><p className="panel-intro">Synthetic data is active. No external calls or credentials are required for this workspace.</p></div><button className="button-primary" onClick={runVerification} disabled={running}><Play size={15} fill="currentColor" /> Start run</button></div><div className="run-card active-run"><div className="run-status"><span className="status-dot" /> Complete</div><div><b>whole_locus_verification</b><span>6,319 blocks · 0 disagreements · PASS</span></div><time>04 min ago</time></div><div className="run-card"><div className="run-status muted"><span className="status-dot" /> Complete</div><div><b>concordance_grade_del52</b><span>3 sources · SUPPORTED · collapsed duplicates</span></div><time>18 min ago</time></div><div className="run-card"><div className="run-status muted"><span className="status-dot" /> Complete</div><div><b>frame_rescue_simulation</b><span>del44 + del45–53 · IN-FRAME</span></div><time>32 min ago</time></div></div></section>}
        </div>
        <footer className="footer"><span>HELIX FORGE · DMD INTEGRATION SYSTEM</span><span><span className="status-dot" /> Offline-ready PWA</span></footer>
      </main>
    </div>
  );
}

// Keep the imported symbol available for narrow tree-shaking configurations.
void PanelLeftOpen;
void Info;
