# Platform Deployments

- Kubernetes
- Air-gapped / offline
- HPC / SLURM
- Single-node edge
