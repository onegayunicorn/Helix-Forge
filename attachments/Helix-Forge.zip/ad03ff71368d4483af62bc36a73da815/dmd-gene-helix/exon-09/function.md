# Exon 9 — Functional Specification

**Domain:** Spectrin-like repeat 1

**Role:** Spectrin-like repeat · rod domain elasticity

## Properties

- Length: **180 nt** (60 codons)
- Starts at reading frame: **phase 0**
- Length mod-3: **0** → clean boundary
- Splicing dependencies: exon-08

## Effect on System

Deleting this exon alone **preserves the reading frame** (Becker-like phenotype).
