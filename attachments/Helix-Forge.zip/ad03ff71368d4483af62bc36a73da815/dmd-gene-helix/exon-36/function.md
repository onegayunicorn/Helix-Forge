# Exon 36 — Functional Specification

**Domain:** Spectrin-like repeat 28

**Role:** Spectrin-like repeat · rod domain elasticity

## Properties

- Length: **120 nt** (40 codons)
- Starts at reading frame: **phase 0**
- Length mod-3: **0** → clean boundary
- Splicing dependencies: exon-35

## Effect on System

Deleting this exon alone **preserves the reading frame** (Becker-like phenotype).
