#!/usr/bin/env python3
"""
DMD Gene System Processor
=========================

Reads ALL exon folders, validates the system state, and reports:
- Reading frame integrity
- System health score
- Protein output prognosis
- Which exons are broken / skipped / healthy

HOW TO USE:
    python3 processor.py              # Check current system state
    python3 processor.py --break 52   # Simulate deleting exon 52
    python3 processor.py --skip 51    # Mark exon 51 as skipped (repair)
    python3 processor.py --restore 52 # Restore exon 52 to healthy
    python3 processor.py --reset      # Reset entire system to healthy

This script treats each exon folder as a "service" in a distributed system.
Change a file in an exon folder → the processor sees the change → system state updates.
"""

import json
import os
import sys
import argparse
from pathlib import Path

GENE_ROOT = Path(__file__).parent
TOTAL_EXONS = 79

# ── Load exon spec ──
def load_exon(n):
    folder = GENE_ROOT / f"exon-{n:02d}"
    spec_file = folder / "spec.json"
    if not spec_file.exists():
        return {"exon_number": n, "status": "MISSING_FOLDER", "length_nt": 0, "mod_3": 0}
    with open(spec_file) as f:
        return json.load(f)

def save_exon(n, spec):
    folder = GENE_ROOT / f"exon-{n:02d}"
    folder.mkdir(exist_ok=True)
    with open(folder / "spec.json", "w") as f:
        json.dump(spec, f, indent=2)

# ── System analysis ──
def analyze_system():
    exons = []
    for i in range(1, TOTAL_EXONS + 1):
        exons.append(load_exon(i))
    
    active = [e for e in exons if e.get("status") in ("healthy", None)]
    broken = [e for e in exons if e.get("status") == "broken"]
    skipped = [e for e in exons if e.get("status") == "skipped"]
    
    total_nt = sum(e["length_nt"] for e in exons)
    removed_nt = sum(e["length_nt"] for e in broken + skipped)
    active_nt = sum(e["length_nt"] for e in active)
    
    in_frame = removed_nt % 3 == 0
    has_damage = len(broken) > 0 or len(skipped) > 0
    
    # Health score
    if not has_damage:
        health = 100
    else:
        affected = len(broken) + len(skipped)
        base = max(0, 100 - affected * 1.2)
        health = round(base if in_frame else base * 0.4)
    
    # Prognosis
    if not has_damage:
        prognosis = "HEALTHY · Full dystrophin · 4,527 aa"
        prognosis_color = "GREEN"
    elif in_frame and health >= 60:
        prognosis = f"BECKER-LIKE · Truncated but functional · ~{round(4527 * active_nt / total_nt)} aa"
        prognosis_color = "CYAN"
    elif in_frame:
        prognosis = f"RESCUED · In-frame but significantly truncated · ~{round(4527 * active_nt / total_nt)} aa"
        prognosis_color = "YELLOW"
    else:
        prognosis = "DUCHENNE · Out-of-frame · Premature stop · Non-functional"
        prognosis_color = "RED"
    
    return {
        "exons": exons,
        "active": active,
        "broken": broken,
        "skipped": skipped,
        "total_nt": total_nt,
        "removed_nt": removed_nt,
        "active_nt": active_nt,
        "in_frame": in_frame,
        "health": health,
        "prognosis": prognosis,
        "prognosis_color": prognosis_color,
        "has_damage": has_damage,
        "mod_3_remainder": removed_nt % 3
    }

# ── Report ──
def print_report(state):
    COLORS = {
        "RED": "\033[91m",
        "GREEN": "\033[92m",
        "YELLOW": "\033[93m",
        "CYAN": "\033[96m",
        "RESET": "\033[0m",
        "BOLD": "\033[1m",
        "DIM": "\033[2m"
    }
    C = COLORS
    
    print(f"\n{C['BOLD']}{'═'*60}{C['RESET']}")
    print(f"{C['BOLD']}  DMD GENE — SYSTEM ANALYSIS{C['RESET']}")
    print(f"{C['BOLD']}{'═'*60}{C['RESET']}")
    
    print(f"\n  Exons:    {len(state['active'])} active · "
          f"{C['RED']}{len(state['broken'])} broken{C['RESET']} · "
          f"{C['CYAN']}{len(state['skipped'])} skipped{C['RESET']}")
    print(f"  Nucleotides: {state['active_nt']:,} active / {state['total_nt']:,} total "
          f"({C['RED']}-{state['removed_nt']:,} removed{C['RESET']})")
    
    frame_color = C['GREEN'] if state['in_frame'] else C['RED']
    frame_status = "IN-FRAME ✅" if state['in_frame'] else f"OUT-OF-FRAME ❌ (mod-3 remainder: {state['mod_3_remainder']})"
    print(f"  Frame:      {frame_color}{frame_status}{C['RESET']}")
    
    # Health bar
    bar_len = 30
    filled = round(state['health'] / 100 * bar_len)
    bar_color = C['GREEN'] if state['health'] > 70 else (C['YELLOW'] if state['health'] > 40 else C['RED'])
    bar = bar_color + '█' * filled + C['DIM'] + '░' * (bar_len - filled) + C['RESET']
    print(f"  Health:     {bar} {state['health']}%")
    
    color = C[state['prognosis_color']]
    print(f"\n  Prognosis:  {C['BOLD']}{color}{state['prognosis']}{C['RESET']}")
    
    # List broken exons
    if state['broken']:
        broken_nums = [str(e['exon_number']) for e in state['broken']]
        print(f"\n  {C['RED']}BROKEN exons: {', '.join(broken_nums)}{C['RESET']}")
    
    if state['skipped']:
        skipped_nums = [str(e['exon_number']) for e in state['skipped']]
        print(f"  {C['CYAN']}SKIPPED exons: {', '.join(skipped_nums)}{C['RESET']}")
    
    # Repair hint
    if state['has_damage'] and not state['in_frame']:
        need = 3 - state['mod_3_remainder']
        print(f"\n  {C['YELLOW']}💡 Repair hint: Remove {need} more nt "
              f"(or skip exons whose combined length mod-3 = {need}){C['RESET']}")
        # Suggest candidate exons to skip
        candidates = []
        for e in state['active']:
            if e['length_nt'] % 3 == need:
                candidates.append(e['exon_number'])
                if len(candidates) >= 5: break
        if candidates:
            print(f"     Candidate exons to skip: {', '.join(map(str, candidates))}")
    
    print(f"\n{C['BOLD']}{'═'*60}{C['RESET']}\n")

# ── Main ──
def main():
    parser = argparse.ArgumentParser(description="DMD Gene System Processor")
    parser.add_argument("--break", type=int, dest="break_exon", metavar="N", help="Break exon N")
    parser.add_argument("--skip", type=int, metavar="N", help="Mark exon N as skipped (repair)")
    parser.add_argument("--restore", type=int, metavar="N", help="Restore exon N to healthy")
    parser.add_argument("--reset", action="store_true", help="Reset all exons to healthy")
    parser.add_argument("--quiet", "-q", action="store_true", help="Minimal output")
    args = parser.parse_args()
    
    # Apply mutations
    if args.reset:
        for i in range(1, TOTAL_EXONS + 1):
            spec = load_exon(i)
            if spec.get("status") != "MISSING_FOLDER":
                spec["status"] = "healthy"
                save_exon(i, spec)
        if not args.quiet:
            print("🔄 System reset — all 79 exons restored to healthy")
    
    if args.break_exon:
        n = args.break_exon
        spec = load_exon(n)
        spec["status"] = "broken"
        save_exon(n, spec)
        if not args.quiet:
            print(f"💥 Exon {n} — BROKEN ({spec['length_nt']} nt removed)")
    
    if args.skip:
        n = args.skip
        spec = load_exon(n)
        spec["status"] = "skipped"
        save_exon(n, spec)
        if not args.quiet:
            print(f"⏭️  Exon {n} — SKIPPED for repair")
    
    if args.restore:
        n = args.restore
        spec = load_exon(n)
        spec["status"] = "healthy"
        save_exon(n, spec)
        if not args.quiet:
            print(f"✅ Exon {n} — RESTORED")
    
    # Analyze and report
    state = analyze_system()
    print_report(state)
    
    # Return exit code based on frame
    return 0 if state['in_frame'] else 1

if __name__ == "__main__":
    sys.exit(main())
