# Exon 49 — Functional Specification

**Domain:** Spectrin-like repeat 41

**Role:** Spectrin-like repeat · rod domain elasticity

## Properties

- Length: **135 nt** (45 codons)
- Starts at reading frame: **phase 0**
- Length mod-3: **0** → clean boundary
- Splicing dependencies: exon-48

## Effect on System

Deleting this exon alone **preserves the reading frame** (Becker-like phenotype).
