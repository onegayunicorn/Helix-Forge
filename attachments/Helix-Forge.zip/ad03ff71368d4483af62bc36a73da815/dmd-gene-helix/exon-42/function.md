# Exon 42 — Functional Specification

**Domain:** Spectrin-like repeat 34

**Role:** Spectrin-like repeat · rod domain elasticity

## Properties

- Length: **174 nt** (58 codons)
- Starts at reading frame: **phase 0**
- Length mod-3: **0** → clean boundary
- Splicing dependencies: exon-41

## Effect on System

Deleting this exon alone **preserves the reading frame** (Becker-like phenotype).
