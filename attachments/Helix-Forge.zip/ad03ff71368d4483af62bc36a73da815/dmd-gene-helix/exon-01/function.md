# Exon 1 — Functional Specification

**Domain:** Actin-binding domain (N-terminus)

**Role:** Translation initiation · START codon · signal peptide

## Properties

- Length: **126 nt** (42 codons)
- Starts at reading frame: **phase 0**
- Length mod-3: **0** → clean boundary
- Splicing dependencies: none (first exon)

## Effect on System

Deleting this exon alone **preserves the reading frame** (Becker-like phenotype).
