# Exon 17 — Functional Specification

**Domain:** Spectrin-like repeat 9

**Role:** Spectrin-like repeat · rod domain elasticity

## Properties

- Length: **147 nt** (49 codons)
- Starts at reading frame: **phase 0**
- Length mod-3: **0** → clean boundary
- Splicing dependencies: exon-16

## Effect on System

Deleting this exon alone **preserves the reading frame** (Becker-like phenotype).
