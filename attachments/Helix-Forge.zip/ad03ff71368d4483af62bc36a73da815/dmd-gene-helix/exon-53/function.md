# Exon 53 — Functional Specification

**Domain:** Spectrin-like repeat 45

**Role:** Spectrin-like repeat · rod domain elasticity

## Properties

- Length: **153 nt** (51 codons)
- Starts at reading frame: **phase 0**
- Length mod-3: **0** → clean boundary
- Splicing dependencies: exon-52

## Effect on System

Deleting this exon alone **preserves the reading frame** (Becker-like phenotype).
