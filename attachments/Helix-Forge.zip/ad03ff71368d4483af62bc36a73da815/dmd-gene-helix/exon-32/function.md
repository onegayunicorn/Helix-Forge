# Exon 32 — Functional Specification

**Domain:** Spectrin-like repeat 24

**Role:** Spectrin-like repeat · rod domain elasticity

## Properties

- Length: **150 nt** (50 codons)
- Starts at reading frame: **phase 0**
- Length mod-3: **0** → clean boundary
- Splicing dependencies: exon-31

## Effect on System

Deleting this exon alone **preserves the reading frame** (Becker-like phenotype).
