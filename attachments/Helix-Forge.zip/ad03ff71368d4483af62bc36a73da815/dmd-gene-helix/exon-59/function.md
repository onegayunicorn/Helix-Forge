# Exon 59 — Functional Specification

**Domain:** Spectrin-like repeat 51

**Role:** Spectrin-like repeat · rod domain elasticity

## Properties

- Length: **177 nt** (59 codons)
- Starts at reading frame: **phase 0**
- Length mod-3: **0** → clean boundary
- Splicing dependencies: exon-58

## Effect on System

Deleting this exon alone **preserves the reading frame** (Becker-like phenotype).
