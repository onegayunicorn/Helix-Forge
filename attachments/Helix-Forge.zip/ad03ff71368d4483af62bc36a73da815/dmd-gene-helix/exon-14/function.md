# Exon 14 — Functional Specification

**Domain:** Spectrin-like repeat 6

**Role:** Spectrin-like repeat · rod domain elasticity

## Properties

- Length: **189 nt** (63 codons)
- Starts at reading frame: **phase 0**
- Length mod-3: **0** → clean boundary
- Splicing dependencies: exon-13

## Effect on System

Deleting this exon alone **preserves the reading frame** (Becker-like phenotype).
