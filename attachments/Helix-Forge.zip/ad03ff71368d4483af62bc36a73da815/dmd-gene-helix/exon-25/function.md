# Exon 25 — Functional Specification

**Domain:** Spectrin-like repeat 17

**Role:** Spectrin-like repeat · rod domain elasticity

## Properties

- Length: **141 nt** (47 codons)
- Starts at reading frame: **phase 0**
- Length mod-3: **0** → clean boundary
- Splicing dependencies: exon-24

## Effect on System

Deleting this exon alone **preserves the reading frame** (Becker-like phenotype).
