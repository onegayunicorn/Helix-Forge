# Exon 29 — Functional Specification

**Domain:** Spectrin-like repeat 21

**Role:** Spectrin-like repeat · rod domain elasticity

## Properties

- Length: **105 nt** (35 codons)
- Starts at reading frame: **phase 0**
- Length mod-3: **0** → clean boundary
- Splicing dependencies: exon-28

## Effect on System

Deleting this exon alone **preserves the reading frame** (Becker-like phenotype).
