# Exon 31 — Functional Specification

**Domain:** Spectrin-like repeat 23

**Role:** Spectrin-like repeat · rod domain elasticity

## Properties

- Length: **126 nt** (42 codons)
- Starts at reading frame: **phase 0**
- Length mod-3: **0** → clean boundary
- Splicing dependencies: exon-30

## Effect on System

Deleting this exon alone **preserves the reading frame** (Becker-like phenotype).
