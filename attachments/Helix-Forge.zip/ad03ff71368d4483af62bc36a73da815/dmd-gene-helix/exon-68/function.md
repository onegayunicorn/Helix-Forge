# Exon 68 — Functional Specification

**Domain:** Cysteine-rich domain

**Role:** Cysteine-rich · dystroglycan binding

## Properties

- Length: **165 nt** (55 codons)
- Starts at reading frame: **phase 0**
- Length mod-3: **0** → clean boundary
- Splicing dependencies: exon-67

## Effect on System

Deleting this exon alone **preserves the reading frame** (Becker-like phenotype).
