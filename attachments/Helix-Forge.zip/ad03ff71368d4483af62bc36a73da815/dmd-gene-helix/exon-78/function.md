# Exon 78 — Functional Specification

**Domain:** C-terminal domain

**Role:** C-terminal · complex assembly signal

## Properties

- Length: **150 nt** (50 codons)
- Starts at reading frame: **phase 0**
- Length mod-3: **0** → clean boundary
- Splicing dependencies: exon-77

## Effect on System

Deleting this exon alone **preserves the reading frame** (Becker-like phenotype).
