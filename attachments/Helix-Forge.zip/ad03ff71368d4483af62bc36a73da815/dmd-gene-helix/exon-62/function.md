# Exon 62 — Functional Specification

**Domain:** Spectrin-like repeat 54

**Role:** Domain transition · spectrin → cysteine-rich

## Properties

- Length: **147 nt** (49 codons)
- Starts at reading frame: **phase 0**
- Length mod-3: **0** → clean boundary
- Splicing dependencies: exon-61

## Effect on System

Deleting this exon alone **preserves the reading frame** (Becker-like phenotype).
