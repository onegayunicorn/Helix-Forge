# Exon 43 — Functional Specification

**Domain:** Spectrin-like repeat 35

**Role:** Spectrin-like repeat · rod domain elasticity

## Properties

- Length: **108 nt** (36 codons)
- Starts at reading frame: **phase 0**
- Length mod-3: **0** → clean boundary
- Splicing dependencies: exon-42

## Effect on System

Deleting this exon alone **preserves the reading frame** (Becker-like phenotype).
