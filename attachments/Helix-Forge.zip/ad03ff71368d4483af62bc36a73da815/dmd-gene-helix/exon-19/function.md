# Exon 19 — Functional Specification

**Domain:** Spectrin-like repeat 11

**Role:** Spectrin-like repeat · rod domain elasticity

## Properties

- Length: **162 nt** (54 codons)
- Starts at reading frame: **phase 0**
- Length mod-3: **0** → clean boundary
- Splicing dependencies: exon-18

## Effect on System

Deleting this exon alone **preserves the reading frame** (Becker-like phenotype).
