# Exon 39 — Functional Specification

**Domain:** Spectrin-like repeat 31

**Role:** Spectrin-like repeat · rod domain elasticity

## Properties

- Length: **114 nt** (38 codons)
- Starts at reading frame: **phase 0**
- Length mod-3: **0** → clean boundary
- Splicing dependencies: exon-38

## Effect on System

Deleting this exon alone **preserves the reading frame** (Becker-like phenotype).
