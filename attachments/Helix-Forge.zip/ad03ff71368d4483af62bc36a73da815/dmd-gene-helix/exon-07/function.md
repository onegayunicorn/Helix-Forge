# Exon 7 — Functional Specification

**Domain:** Actin-binding domain (N-terminus)

**Role:** Actin-binding scaffold · structural support

## Properties

- Length: **66 nt** (22 codons)
- Starts at reading frame: **phase 0**
- Length mod-3: **0** → clean boundary
- Splicing dependencies: exon-06

## Effect on System

Deleting this exon alone **preserves the reading frame** (Becker-like phenotype).
