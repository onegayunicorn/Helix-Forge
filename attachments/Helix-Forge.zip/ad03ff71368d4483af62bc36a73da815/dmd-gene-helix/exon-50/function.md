# Exon 50 — Functional Specification

**Domain:** Spectrin-like repeat 42

**Role:** Hinge region 3 · common deletion breakpoint

## Properties

- Length: **171 nt** (57 codons)
- Starts at reading frame: **phase 0**
- Length mod-3: **0** → clean boundary
- Splicing dependencies: exon-49

## Effect on System

Deleting this exon alone **preserves the reading frame** (Becker-like phenotype).
