# Exon 21 — Functional Specification

**Domain:** Spectrin-like repeat 13

**Role:** Spectrin-like repeat · rod domain elasticity

## Properties

- Length: **138 nt** (46 codons)
- Starts at reading frame: **phase 0**
- Length mod-3: **0** → clean boundary
- Splicing dependencies: exon-20

## Effect on System

Deleting this exon alone **preserves the reading frame** (Becker-like phenotype).
