# Exon 8 — Functional Specification

**Domain:** Actin-binding domain (N-terminus)

**Role:** Domain boundary · hinge region 1

## Properties

- Length: **198 nt** (66 codons)
- Starts at reading frame: **phase 0**
- Length mod-3: **0** → clean boundary
- Splicing dependencies: exon-07

## Effect on System

Deleting this exon alone **preserves the reading frame** (Becker-like phenotype).
