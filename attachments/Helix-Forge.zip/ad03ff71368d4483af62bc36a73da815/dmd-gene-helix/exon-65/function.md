# Exon 65 — Functional Specification

**Domain:** Cysteine-rich domain

**Role:** Cysteine-rich · membrane anchor

## Properties

- Length: **138 nt** (46 codons)
- Starts at reading frame: **phase 0**
- Length mod-3: **0** → clean boundary
- Splicing dependencies: exon-64

## Effect on System

Deleting this exon alone **preserves the reading frame** (Becker-like phenotype).
