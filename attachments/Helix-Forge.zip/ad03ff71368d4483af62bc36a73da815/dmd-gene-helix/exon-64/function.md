# Exon 64 — Functional Specification

**Domain:** Cysteine-rich domain

**Role:** Cysteine-rich · membrane anchor

## Properties

- Length: **159 nt** (53 codons)
- Starts at reading frame: **phase 0**
- Length mod-3: **0** → clean boundary
- Splicing dependencies: exon-63

## Effect on System

Deleting this exon alone **preserves the reading frame** (Becker-like phenotype).
