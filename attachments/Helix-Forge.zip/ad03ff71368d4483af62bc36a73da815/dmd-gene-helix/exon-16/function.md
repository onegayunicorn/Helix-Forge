# Exon 16 — Functional Specification

**Domain:** Spectrin-like repeat 8

**Role:** Spectrin-like repeat · rod domain elasticity

## Properties

- Length: **171 nt** (57 codons)
- Starts at reading frame: **phase 0**
- Length mod-3: **0** → clean boundary
- Splicing dependencies: exon-15

## Effect on System

Deleting this exon alone **preserves the reading frame** (Becker-like phenotype).
