# Exon 12 — Functional Specification

**Domain:** Spectrin-like repeat 4

**Role:** Spectrin-like repeat · rod domain elasticity

## Properties

- Length: **117 nt** (39 codons)
- Starts at reading frame: **phase 0**
- Length mod-3: **0** → clean boundary
- Splicing dependencies: exon-11

## Effect on System

Deleting this exon alone **preserves the reading frame** (Becker-like phenotype).
