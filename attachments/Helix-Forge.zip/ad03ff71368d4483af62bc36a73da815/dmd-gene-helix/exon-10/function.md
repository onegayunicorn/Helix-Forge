# Exon 10 — Functional Specification

**Domain:** Spectrin-like repeat 2

**Role:** Spectrin-like repeat · rod domain elasticity

## Properties

- Length: **132 nt** (44 codons)
- Starts at reading frame: **phase 0**
- Length mod-3: **0** → clean boundary
- Splicing dependencies: exon-09

## Effect on System

Deleting this exon alone **preserves the reading frame** (Becker-like phenotype).
