# Exon 2 — Functional Specification

**Domain:** Actin-binding domain (N-terminus)

**Role:** LARGEST exon · major actin-binding interface

## Properties

- Length: **2163 nt** (721 codons)
- Starts at reading frame: **phase 0**
- Length mod-3: **0** → clean boundary
- Splicing dependencies: exon-01

## Effect on System

Deleting this exon alone **preserves the reading frame** (Becker-like phenotype).
