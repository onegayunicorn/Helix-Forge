# Exon 70 — Functional Specification

**Domain:** C-terminal domain

**Role:** Beta-dystroglycan binding motif

## Properties

- Length: **129 nt** (43 codons)
- Starts at reading frame: **phase 0**
- Length mod-3: **0** → clean boundary
- Splicing dependencies: exon-69

## Effect on System

Deleting this exon alone **preserves the reading frame** (Becker-like phenotype).
