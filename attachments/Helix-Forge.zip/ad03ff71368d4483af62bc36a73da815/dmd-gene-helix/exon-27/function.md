# Exon 27 — Functional Specification

**Domain:** Spectrin-like repeat 19

**Role:** Spectrin-like repeat · rod domain elasticity

## Properties

- Length: **159 nt** (53 codons)
- Starts at reading frame: **phase 0**
- Length mod-3: **0** → clean boundary
- Splicing dependencies: exon-26

## Effect on System

Deleting this exon alone **preserves the reading frame** (Becker-like phenotype).
