# Exon 79 — Functional Specification

**Domain:** C-terminal domain

**Role:** STOP codon · C-terminal · protein folding signal

## Properties

- Length: **177 nt** (59 codons)
- Starts at reading frame: **phase 0**
- Length mod-3: **0** → clean boundary
- Splicing dependencies: exon-78, exon-01

## Effect on System

Deleting this exon alone **preserves the reading frame** (Becker-like phenotype).
