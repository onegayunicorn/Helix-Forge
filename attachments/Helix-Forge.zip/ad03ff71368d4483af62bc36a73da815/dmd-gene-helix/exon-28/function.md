# Exon 28 — Functional Specification

**Domain:** Spectrin-like repeat 20

**Role:** Spectrin-like repeat · rod domain elasticity

## Properties

- Length: **183 nt** (61 codons)
- Starts at reading frame: **phase 0**
- Length mod-3: **0** → clean boundary
- Splicing dependencies: exon-27

## Effect on System

Deleting this exon alone **preserves the reading frame** (Becker-like phenotype).
