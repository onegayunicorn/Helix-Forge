# Exon 38 — Functional Specification

**Domain:** Spectrin-like repeat 30

**Role:** Spectrin-like repeat · rod domain elasticity

## Properties

- Length: **186 nt** (62 codons)
- Starts at reading frame: **phase 0**
- Length mod-3: **0** → clean boundary
- Splicing dependencies: exon-37

## Effect on System

Deleting this exon alone **preserves the reading frame** (Becker-like phenotype).
