# Exon 69 — Functional Specification

**Domain:** C-terminal domain

**Role:** C-terminal · complex assembly signal

## Properties

- Length: **141 nt** (47 codons)
- Starts at reading frame: **phase 0**
- Length mod-3: **0** → clean boundary
- Splicing dependencies: exon-68

## Effect on System

Deleting this exon alone **preserves the reading frame** (Becker-like phenotype).
