# Exon 24 — Functional Specification

**Domain:** Spectrin-like repeat 16

**Role:** Spectrin-like repeat · rod domain elasticity

## Properties

- Length: **165 nt** (55 codons)
- Starts at reading frame: **phase 0**
- Length mod-3: **0** → clean boundary
- Splicing dependencies: exon-23

## Effect on System

Deleting this exon alone **preserves the reading frame** (Becker-like phenotype).
