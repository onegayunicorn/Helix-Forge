# Exon 55 — Functional Specification

**Domain:** Spectrin-like repeat 47

**Role:** Spectrin-like repeat · rod domain elasticity

## Properties

- Length: **168 nt** (56 codons)
- Starts at reading frame: **phase 0**
- Length mod-3: **0** → clean boundary
- Splicing dependencies: exon-54

## Effect on System

Deleting this exon alone **preserves the reading frame** (Becker-like phenotype).
