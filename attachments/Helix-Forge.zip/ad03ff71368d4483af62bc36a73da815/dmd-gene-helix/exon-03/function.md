# Exon 3 — Functional Specification

**Domain:** Actin-binding domain (N-terminus)

**Role:** Actin-binding scaffold · structural support

## Properties

- Length: **141 nt** (47 codons)
- Starts at reading frame: **phase 0**
- Length mod-3: **0** → clean boundary
- Splicing dependencies: exon-02

## Effect on System

Deleting this exon alone **preserves the reading frame** (Becker-like phenotype).
