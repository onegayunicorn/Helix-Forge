# Exon 52 — Functional Specification

**Domain:** Spectrin-like repeat 44

**Role:** HOTSPOT · most frequently deleted exon in DMD

## Properties

- Length: **141 nt** (47 codons)
- Starts at reading frame: **phase 0**
- Length mod-3: **0** → clean boundary
- Splicing dependencies: exon-51

## Effect on System

Deleting this exon alone **preserves the reading frame** (Becker-like phenotype).
