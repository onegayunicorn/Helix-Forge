# 🧬 DMD Gene as a File System

> **Each exon is a folder. Each folder contains files that describe how that exon works. Change a file → the gene process changes.**

This is a tangible, inspectable, editable model of the DMD gene. Instead of abstract diagrams, the whole system lives as files and folders on your computer. The `processor.py` script reads every exon folder, validates the "system state," and tells you whether the gene is healthy, broken, or rescued.

---

## 📁 The Structure

```
dmd-gene-helix/          ← The double helix · the whole gene
│
├── exon-01/             ← Each exon = a service folder
│   ├── spec.json        ← Length, frame, dependencies, status
│   ├── sequence.txt     ← DNA sequence
│   └── function.md      ← What this exon contributes
│
├── exon-02/
│   ...
├── exon-79/
│
├── gene-structure.json  ← Master blueprint · domains · hotspots · repair strategies
├── processor.py         ← 🧠 The gene process · reads all folders · computes health
├── splicing-order.txt   ← The assembly pipeline · 79 exons in order
└── README.md            ← This file
```

---

## 🚀 Quick Start

```bash
# Check system health (all exons healthy)
python3 processor.py

# Simulate DMD — break exon 52 (the most common deletion)
python3 processor.py --break 52

# Try to repair — skip adjacent exons to reframe
python3 processor.py --skip 51
python3 processor.py --skip 53

# Restore everything
python3 processor.py --reset
```

---

## 🔬 How It Works

### The Fundamental Law
> **Total nucleotides removed must be divisible by 3 to preserve the reading frame.**

Each exon folder's `spec.json` has a `"length_nt"` and `"mod_3"` field. When you mark an exon as `broken` or `skipped`, the processor adds up all removed nucleotides and checks:

```
total_removed % 3 == 0 → IN-FRAME ✅ (Becker-like · functional protein)
total_removed % 3 != 0 → OUT-OF-FRAME ❌ (Duchenne · premature stop)
```

### Each Exon Is a Service
- **`spec.json`** — The service contract. Change `"status"` to `"broken"` and the system degrades.
- **`sequence.txt`** — The DNA code. Edit this and you've mutated the gene.
- **`function.md`** — Human-readable documentation of what this exon does.

### The Ripple Effect
Edit one file in one exon folder → run `processor.py` → the entire system state recalculates. **This is exactly how a real gene works** — one change ripples through the whole assembly process.

---

## 🧪 Experiments to Try

### 1. The Classic DMD Mutation
```bash
python3 processor.py --reset
python3 processor.py --break 52
```
**Result:** OUT-OF-FRAME · Duchenne phenotype. Exon 52's length mod-3 ≠ 0.

### 2. Exon Skipping Rescue
```bash
python3 processor.py --skip 51
python3 processor.py --skip 53
```
**Result:** Now in-frame! By removing exons whose combined length mod-3 = 1, we cancel out exon 52's remainder.

### 3. Multi-Exon Deletion (Becker)
```bash
python3 processor.py --reset
for i in $(seq 45 53); do python3 processor.py -q --break $i; done
python3 processor.py
```
**Result:** Often IN-FRAME naturally. This is why some large deletions produce milder Becker MD.

### 4. Manual Edit
Open `exon-52/spec.json` in a text editor. Change:
```json
"status": "healthy"
```
to:
```json
"status": "broken"
```
Then run `python3 processor.py`. **You just broke the gene with a text editor.**

---

## 🎯 The Big Idea

This isn't just a model of a gene. It's a **paradigm**:

- **Biology** → Each exon is a service. Splicing is orchestration. Reading frame is system integrity.
- **Software** → Each folder is a microservice. Dependencies are in `spec.json`. The processor is the runtime.
- **Repair** → Exon skipping = circuit breaker pattern. Gene therapy = service restoration.

**Break it. Study it. Fix it. See how the system reacts.**

That's the whole point.
