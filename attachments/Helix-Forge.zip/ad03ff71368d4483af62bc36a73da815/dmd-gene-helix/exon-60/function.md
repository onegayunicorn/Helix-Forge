# Exon 60 — Functional Specification

**Domain:** Spectrin-like repeat 52

**Role:** Spectrin-like repeat · rod domain elasticity

## Properties

- Length: **111 nt** (37 codons)
- Starts at reading frame: **phase 0**
- Length mod-3: **0** → clean boundary
- Splicing dependencies: exon-59

## Effect on System

Deleting this exon alone **preserves the reading frame** (Becker-like phenotype).
