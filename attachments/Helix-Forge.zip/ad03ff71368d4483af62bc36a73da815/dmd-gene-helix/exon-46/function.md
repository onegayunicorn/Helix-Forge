# Exon 46 — Functional Specification

**Domain:** Spectrin-like repeat 38

**Role:** Spectrin-like repeat · rod domain elasticity

## Properties

- Length: **123 nt** (41 codons)
- Starts at reading frame: **phase 0**
- Length mod-3: **0** → clean boundary
- Splicing dependencies: exon-45

## Effect on System

Deleting this exon alone **preserves the reading frame** (Becker-like phenotype).
