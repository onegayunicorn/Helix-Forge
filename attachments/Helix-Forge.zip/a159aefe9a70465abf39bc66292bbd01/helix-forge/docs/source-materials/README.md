# Source Materials

Reference documents and specifications used to build Helix-Forge:
- `README-source.md` — Original project README
- `DDGS-System.pdf` — Digital DMD Gene Variant Integration System specification
- `Helix-Forge-Spec.pdf` — Helix-Forge blueprint
- `Accio-Share.mht` — Accio shared workspace export
- `Accio-Link.url` — Accio shared link reference
